'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Calendar, 
  CheckSquare, 
  Plus, 
  Settings, 
  User,
  Clock,
  Target,
  TrendingUp
} from 'lucide-react'
import TaskManager from './TaskManager'
import ScheduleView from './ScheduleView'

interface DashboardProps {
  userProfile: {
    name: string
    workStyle: string
    primaryGoal: string
    preferredTime: string
  }
}

const sidebarItems = [
  { id: 'tasks', label: 'Tasks', icon: CheckSquare },
  { id: 'schedule', label: 'Schedule', icon: Calendar },
  { id: 'analytics', label: 'Analytics', icon: TrendingUp },
  { id: 'settings', label: 'Settings', icon: Settings }
]

export default function Dashboard({ userProfile }: DashboardProps) {
  console.log('Dashboard rendered with user profile:', userProfile)
  
  const [activeTab, setActiveTab] = useState('tasks')
  const [tasks, setTasks] = useState<Array<{
    id: string
    title: string
    description: string
    completed: boolean
    dueDate?: string
    priority: 'low' | 'medium' | 'high'
    estimatedTime?: number
  }>>([])

  const addTask = (task: {
    title: string
    description: string
    dueDate?: string
    priority: 'low' | 'medium' | 'high'
    estimatedTime?: number
  }) => {
    console.log('Adding new task:', task)
    const newTask = {
      id: Date.now().toString(),
      ...task,
      completed: false
    }
    setTasks(prev => [...prev, newTask])
  }

  const toggleTaskComplete = (taskId: string) => {
    console.log('Toggling task completion:', taskId)
    setTasks(prev => 
      prev.map(task => 
        task.id === taskId 
          ? { ...task, completed: !task.completed }
          : task
      )
    )
  }

  const deleteTask = (taskId: string) => {
    console.log('Deleting task:', taskId)
    setTasks(prev => prev.filter(task => task.id !== taskId))
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg flex flex-col">
        {/* User profile section */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-500 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-900">
                Welcome, {userProfile.name}!
              </h2>
              <p className="text-sm text-gray-500 capitalize">
                {userProfile.workStyle} style
              </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          {sidebarItems.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors hover:scale-105 ${
                  activeTab === item.id
                    ? 'bg-primary-50 text-primary-600 border border-primary-200'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            )
          })}
        </nav>

        {/* Stats footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="text-lg font-bold text-gray-900">
                {tasks.filter(t => t.completed).length}
              </div>
              <div className="text-xs text-gray-500">Completed</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="text-lg font-bold text-gray-900">
                {tasks.filter(t => !t.completed).length}
              </div>
              <div className="text-xs text-gray-500">Pending</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="p-8"
        >
          {activeTab === 'tasks' && (
            <TaskManager
              tasks={tasks}
              onAddTask={addTask}
              onToggleComplete={toggleTaskComplete}
              onDeleteTask={deleteTask}
              userProfile={userProfile}
            />
          )}
          
          {activeTab === 'schedule' && (
            <ScheduleView 
              tasks={tasks}
              userProfile={userProfile}
            />
          )}
          
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold text-gray-900">Analytics</h1>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <Target className="w-8 h-8 text-primary-500" />
                    <h3 className="text-lg font-semibold">Task Completion</h3>
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    {tasks.length > 0 ? Math.round((tasks.filter(t => t.completed).length / tasks.length) * 100) : 0}%
                  </div>
                  <p className="text-sm text-gray-500">
                    {tasks.filter(t => t.completed).length} of {tasks.length} tasks completed
                  </p>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <Clock className="w-8 h-8 text-primary-500" />
                    <h3 className="text-lg font-semibold">Time Tracked</h3>
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    {tasks.reduce((acc, task) => acc + (task.estimatedTime || 0), 0)}h
                  </div>
                  <p className="text-sm text-gray-500">
                    Total estimated time for all tasks
                  </p>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <TrendingUp className="w-8 h-8 text-primary-500" />
                    <h3 className="text-lg font-semibold">Productivity</h3>
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    {userProfile.primaryGoal === 'tasks' ? 'High' : 'Good'}
                  </div>
                  <p className="text-sm text-gray-500">
                    Based on your {userProfile.primaryGoal} focus
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
              <div className="bg-white rounded-xl p-6 shadow-sm max-w-2xl">
                <h3 className="text-lg font-semibold mb-4">Profile Information</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Name
                    </label>
                    <input 
                      type="text" 
                      value={userProfile.name}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Work Style
                    </label>
                    <input 
                      type="text" 
                      value={userProfile.workStyle}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg capitalize"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Primary Goal
                    </label>
                    <input 
                      type="text" 
                      value={userProfile.primaryGoal}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg capitalize"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Preferred Time
                    </label>
                    <input 
                      type="text" 
                      value={userProfile.preferredTime}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg capitalize"
                      readOnly
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}