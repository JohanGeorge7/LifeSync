'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronRight, CheckCircle } from 'lucide-react'

interface OnboardingFlowProps {
  onComplete: (profile: {
    name: string
    workStyle: string
    primaryGoal: string
    preferredTime: string
  }) => void
}

const questions = [
  {
    id: 'welcome',
    title: 'Welcome to Your Productivity Hub',
    subtitle: 'Let\'s personalize your experience in just a few steps',
    type: 'welcome'
  },
  {
    id: 'name',
    title: 'What should we call you?',
    subtitle: 'This will help us personalize your experience',
    type: 'input',
    placeholder: 'Enter your name'
  },
  {
    id: 'workStyle',
    title: 'How do you prefer to work?',
    subtitle: 'This helps us customize your dashboard',
    type: 'choice',
    options: [
      { value: 'focused', label: 'Deep Focus Sessions', desc: 'Long uninterrupted work blocks' },
      { value: 'flexible', label: 'Flexible Scheduling', desc: 'Adaptable to changes throughout the day' },
      { value: 'structured', label: 'Structured Planning', desc: 'Detailed schedules and time blocks' }
    ]
  },
  {
    id: 'primaryGoal',
    title: 'What\'s your main productivity goal?',
    subtitle: 'We\'ll tailor features to support this',
    type: 'choice',
    options: [
      { value: 'tasks', label: 'Complete More Tasks', desc: 'Focus on task management and completion' },
      { value: 'time', label: 'Better Time Management', desc: 'Optimize how you spend your time' },
      { value: 'balance', label: 'Work-Life Balance', desc: 'Maintain healthy boundaries and habits' }
    ]
  },
  {
    id: 'preferredTime',
    title: 'When are you most productive?',
    subtitle: 'We\'ll suggest optimal scheduling',
    type: 'choice',
    options: [
      { value: 'morning', label: 'Early Morning', desc: '6AM - 10AM' },
      { value: 'midday', label: 'Mid-Day', desc: '10AM - 2PM' },
      { value: 'afternoon', label: 'Afternoon', desc: '2PM - 6PM' },
      { value: 'evening', label: 'Evening', desc: '6PM - 10PM' }
    ]
  }
]

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  console.log('OnboardingFlow component rendered')
  
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})

  const currentQuestion = questions[currentStep]
  const isLastStep = currentStep === questions.length - 1

  const handleNext = () => {
    console.log('Moving to next step, current answers:', answers)
    
    if (isLastStep) {
      onComplete({
        name: answers.name || 'User',
        workStyle: answers.workStyle || 'flexible',
        primaryGoal: answers.primaryGoal || 'tasks',
        preferredTime: answers.preferredTime || 'morning'
      })
    } else {
      setCurrentStep(prev => prev + 1)
    }
  }

  const handleAnswer = (value: string) => {
    console.log('Answer selected:', { questionId: currentQuestion.id, value })
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: value }))
  }

  const canProceed = currentQuestion.type === 'welcome' || answers[currentQuestion.id]

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-500">
              Step {currentStep + 1} of {questions.length}
            </span>
            <span className="text-sm text-gray-500">
              {Math.round(((currentStep + 1) / questions.length) * 100)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / questions.length) * 100}%` }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="space-y-8"
          >
            {/* Question header */}
            <div className="text-center space-y-4">
              <h1 className="text-3xl font-bold text-gray-900">
                {currentQuestion.title}
              </h1>
              <p className="text-lg text-gray-600">
                {currentQuestion.subtitle}
              </p>
            </div>

            {/* Question content */}
            <div className="space-y-6">
              {currentQuestion.type === 'input' && (
                <div className="max-w-md mx-auto">
                  <input
                    type="text"
                    placeholder={currentQuestion.placeholder}
                    value={answers[currentQuestion.id] || ''}
                    onChange={(e) => handleAnswer(e.target.value)}
                    className="w-full px-6 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-primary-500 focus:outline-none transition-colors"
                    autoFocus
                  />
                </div>
              )}

              {currentQuestion.type === 'choice' && currentQuestion.options && (
                <div className="space-y-4 max-w-2xl mx-auto">
                  {currentQuestion.options.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handleAnswer(option.value)}
                      className={`w-full p-6 rounded-xl border-2 text-left transition-all hover:scale-105 ${
                        answers[currentQuestion.id] === option.value
                          ? 'border-primary-500 bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-900 mb-1">
                            {option.label}
                          </h3>
                          <p className="text-gray-600 text-sm">
                            {option.desc}
                          </p>
                        </div>
                        {answers[currentQuestion.id] === option.value && (
                          <CheckCircle className="w-6 h-6 text-primary-500" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Navigation */}
            <div className="flex justify-center pt-8">
              <button
                onClick={handleNext}
                disabled={!canProceed}
                className={`px-8 py-4 rounded-xl font-semibold flex items-center gap-2 transition-all hover:scale-105 ${
                  canProceed
                    ? 'bg-primary-500 text-white hover:bg-primary-600'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                {isLastStep ? 'Get Started' : 'Continue'}
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}