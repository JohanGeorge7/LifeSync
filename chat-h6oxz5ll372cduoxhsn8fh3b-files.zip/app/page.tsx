'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import OnboardingFlow from './components/OnboardingFlow'
import Dashboard from './components/Dashboard'

export default function Home() {
  console.log('Home component rendered')
  
  const [isOnboardingComplete, setIsOnboardingComplete] = useState(false)
  const [userProfile, setUserProfile] = useState<{
    name: string
    workStyle: string
    primaryGoal: string
    preferredTime: string
  } | null>(null)

  const handleOnboardingComplete = (profile: {
    name: string
    workStyle: string
    primaryGoal: string
    preferredTime: string
  }) => {
    console.log('Onboarding completed with profile:', profile)
    setUserProfile(profile)
    setIsOnboardingComplete(true)
  }

  return (
    <main className="min-h-screen bg-gray-50">
      {!isOnboardingComplete ? (
        <OnboardingFlow onComplete={handleOnboardingComplete} />
      ) : (
        <Dashboard userProfile={userProfile!} />
      )}
    </main>
  )
}